import json, sys
try:
    d = json.load(sys.stdin)
except Exception as e:
    print('ERR', e); sys.exit(1)
if isinstance(d, dict):
    print('ERR', json.dumps(d.get('error', {}).get('notes', d))); sys.exit(1)
for s in d:
    print(json.dumps(s.get('results')))
