#!/bin/bash
# d1q.sh "SQL"  -> prints result rows of each statement against prod D1 (private helper)
cd /home/sprite/collision_app/pages || exit 1
export CLOUDFLARE_API_TOKEN=$(cat ../.prod.cftoken)
../wr d1 execute collisionpro --remote --json --command "$1" 2>/dev/null | python3 /home/sprite/collision_app/d1q.py
