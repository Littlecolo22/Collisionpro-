#!/bin/bash
# d1l.sh "SQL" -> local dev D1 (pages_local state)
cd /home/sprite/collision_app/pages_local || exit 1
HOME=../.wr-home ../wr d1 execute collisionpro --local --json --command "$1" 2>/dev/null | python3 /home/sprite/collision_app/d1q.py
